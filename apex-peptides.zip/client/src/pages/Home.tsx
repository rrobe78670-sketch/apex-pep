/* =============================================================
   HOME PAGE — Apex Peptides
   Dark Scientific Precision Theme: Biotech Noir
   Sections: Hero, Products, Why Apex, Research, FAQ, CTA
   ============================================================= */

import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  ChevronRight,
  FlaskConical,
  Shield,
  Microscope,
  Truck,
  Star,
  ChevronDown,
  CheckCircle2,
  Award,
  Zap,
} from "lucide-react";

// ── Counter animation hook ──────────────────────────────────────
function useCountUp(target: number, duration = 1500, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);
  return count;
}

// ── Intersection observer hook ──────────────────────────────────
function useInView(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, inView };
}

// ── FAQ Item ────────────────────────────────────────────────────
function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className="border border-white/8 rounded-xl overflow-hidden transition-all duration-300"
      style={{ background: open ? "oklch(0.16 0.025 250)" : "oklch(0.14 0.025 250)" }}
    >
      <button
        className="w-full flex items-center justify-between p-5 text-left"
        onClick={() => setOpen(!open)}
      >
        <span
          className="text-sm font-medium text-white pr-4"
          style={{ fontFamily: "var(--font-display)" }}
        >
          {q}
        </span>
        <ChevronDown
          className={`w-4 h-4 text-[oklch(0.72_0.20_178)] flex-shrink-0 transition-transform duration-300 ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && (
        <div className="px-5 pb-5">
          <p className="text-sm text-[oklch(0.65_0.04_230)] leading-relaxed">{a}</p>
        </div>
      )}
    </div>
  );
}

// ── Main Component ──────────────────────────────────────────────
export default function Home() {
  const statsRef = useInView(0.3);
  const c1 = useCountUp(99, 1200, statsRef.inView);
  const c2 = useCountUp(5000, 1500, statsRef.inView);
  const c3 = useCountUp(48, 1000, statsRef.inView);

  return (
    <div className="min-h-screen bg-[oklch(0.12_0.025_250)]">
      <Navbar />

      {/* ── HERO ─────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663512579342/ahWG5azqh8H7YhFAqDURgu/hero-banner-o4i8oGYDCDVindryyvWtDQ.webp)`,
          }}
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.12_0.025_250/0.92)] via-[oklch(0.12_0.025_250/0.75)] to-[oklch(0.12_0.025_250/0.4)]" />
        {/* Molecular dot grid */}
        <div className="absolute inset-0 molecular-bg opacity-30" />

        <div className="container relative z-10 pt-24 pb-16">
          <div className="max-w-2xl">
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[oklch(0.72_0.20_178/30%)] bg-[oklch(0.72_0.20_178/10%)] mb-6 animate-fade-up"
              style={{ animationDelay: "0.1s", opacity: 0, animationFillMode: "forwards" }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[oklch(0.72_0.20_178)] animate-pulse" />
              <span
                className="text-xs font-medium text-[oklch(0.72_0.20_178)] tracking-wider uppercase"
                style={{ fontFamily: "var(--font-mono)" }}
              >
                Research Grade · ≥99% Purity
              </span>
            </div>

            {/* Headline */}
            <h1
              className="text-5xl lg:text-7xl font-bold text-white leading-[1.05] tracking-tight mb-6 animate-fade-up"
              style={{
                fontFamily: "var(--font-display)",
                animationDelay: "0.2s",
                opacity: 0,
                animationFillMode: "forwards",
              }}
            >
              Next-Generation
              <br />
              <span className="teal-gradient-text">Research Peptides</span>
            </h1>

            {/* Sub */}
            <p
              className="text-lg text-[oklch(0.72_0.06_230)] leading-relaxed mb-8 max-w-lg animate-fade-up"
              style={{
                animationDelay: "0.35s",
                opacity: 0,
                animationFillMode: "forwards",
              }}
            >
              Premium-grade Retatrutide and BPC-157 synthesized to the highest
              standards of purity. Trusted by research institutions worldwide.
            </p>

            {/* CTAs */}
            <div
              className="flex flex-wrap gap-3 animate-fade-up"
              style={{
                animationDelay: "0.5s",
                opacity: 0,
                animationFillMode: "forwards",
              }}
            >
              <Link href="/products/retatrutide">
                <Button
                  size="lg"
                  className="bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-bold px-6 h-12 text-sm tracking-wide"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Shop Retatrutide
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
              <Link href="/products/bpc-157">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/8 hover:border-[oklch(0.72_0.20_178/40%)] font-semibold px-6 h-12 text-sm"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Shop BPC-157
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 animate-bounce">
          <div className="w-px h-8 bg-gradient-to-b from-transparent to-[oklch(0.72_0.20_178/50%)]" />
          <ChevronDown className="w-4 h-4 text-[oklch(0.72_0.20_178/50%)]" />
        </div>
      </section>

      {/* ── STATS BAR ────────────────────────────────────────── */}
      <div ref={statsRef.ref} className="bg-[oklch(0.14_0.025_250)] border-y border-white/8">
        <div className="container py-8">
          <div className="grid grid-cols-3 gap-4 divide-x divide-white/8">
            {[
              { value: `${c1}%`, label: "Purity Guaranteed", suffix: "" },
              { value: `${c2.toLocaleString()}+`, label: "Orders Fulfilled", suffix: "" },
              { value: `${c3}h`, label: "Dispatch Time", suffix: "" },
            ].map((stat) => (
              <div key={stat.label} className="text-center px-4">
                <div
                  className="text-3xl lg:text-4xl font-bold teal-gradient-text mb-1"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {stat.value}
                </div>
                <div className="text-xs text-[oklch(0.55_0.04_230)] tracking-wide uppercase" style={{ fontFamily: "var(--font-mono)" }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── PRODUCTS ─────────────────────────────────────────── */}
      <section className="py-24 lg:py-32">
        <div className="container">
          {/* Section header */}
          <div className="mb-16">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px flex-1 max-w-[60px] bg-[oklch(0.72_0.20_178/40%)]" />
              <span
                className="text-xs font-medium text-[oklch(0.72_0.20_178)] tracking-widest uppercase"
                style={{ fontFamily: "var(--font-mono)" }}
              >
                Our Catalog
              </span>
            </div>
            <h2
              className="text-4xl lg:text-5xl font-bold text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Research Peptides
            </h2>
          </div>

          {/* Product Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Retatrutide Card */}
            <div className="group relative rounded-2xl overflow-hidden border border-white/8 teal-glow-hover bg-[oklch(0.14_0.025_250)]">
              <div className="absolute inset-0 bg-gradient-to-br from-[oklch(0.72_0.20_178/5%)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="flex flex-col md:flex-row">
                {/* Image */}
                <div className="md:w-2/5 relative overflow-hidden">
                  <div className="aspect-[3/4] md:aspect-auto md:h-full min-h-[280px]">
                    <img
                      src="https://d2xsxph8kpxj0f.cloudfront.net/310519663512579342/ahWG5azqh8H7YhFAqDURgu/retatrutide-product-inYZrAwmtJEhntXDBrpfmb.webp"
                      alt="Retatrutide Peptide"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[oklch(0.14_0.025_250/60%)]" />
                  </div>
                </div>

                {/* Content */}
                <div className="md:w-3/5 p-6 lg:p-8 flex flex-col justify-between">
                  <div>
                    {/* Tags */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span
                        className="px-2 py-0.5 rounded text-xs bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)] border border-[oklch(0.72_0.20_178/20%)] purity-badge"
                      >
                        Triple Agonist
                      </span>
                      <span
                        className="px-2 py-0.5 rounded text-xs bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)] border border-[oklch(0.72_0.20_178/20%)] purity-badge"
                      >
                        ≥99% Purity
                      </span>
                    </div>

                    <h3
                      className="text-2xl lg:text-3xl font-bold text-white mb-2"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      Retatrutide
                    </h3>
                    <p
                      className="text-xs text-[oklch(0.55_0.04_230)] mb-4 purity-badge"
                    >
                      LY3437943 · GIP/GLP-1/GCG Receptor Agonist · 39 AA
                    </p>
                    <p className="text-sm text-[oklch(0.65_0.04_230)] leading-relaxed mb-6">
                      A novel triple-receptor agonist targeting GIP, GLP-1, and glucagon receptors simultaneously. Demonstrated up to 24.2% weight reduction in Phase 2 clinical trials over 48 weeks.
                    </p>

                    {/* Key specs */}
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      {[
                        { label: "Molecular Weight", value: "~4.6 kDa" },
                        { label: "Form", value: "Lyophilized" },
                        { label: "Storage", value: "-20°C" },
                        { label: "Sequence", value: "39 AA" },
                      ].map((spec) => (
                        <div key={spec.label} className="bg-[oklch(0.12_0.025_250)] rounded-lg p-2.5">
                          <div className="text-xs text-[oklch(0.50_0.03_230)] mb-0.5" style={{ fontFamily: "var(--font-mono)" }}>
                            {spec.label}
                          </div>
                          <div className="text-sm font-medium text-white" style={{ fontFamily: "var(--font-mono)" }}>
                            {spec.value}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-white" style={{ fontFamily: "var(--font-display)" }}>
                        From $89
                      </div>
                      <div className="text-xs text-[oklch(0.50_0.03_230)]">per vial</div>
                    </div>
                    <Link href="/products/retatrutide">
                      <Button
                        className="bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-bold"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        View Product
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            {/* BPC-157 Card */}
            <div className="group relative rounded-2xl overflow-hidden border border-white/8 teal-glow-hover bg-[oklch(0.14_0.025_250)]">
              <div className="absolute inset-0 bg-gradient-to-br from-[oklch(0.72_0.20_178/5%)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="flex flex-col md:flex-row">
                {/* Image */}
                <div className="md:w-2/5 relative overflow-hidden">
                  <div className="aspect-[3/4] md:aspect-auto md:h-full min-h-[280px]">
                    <img
                      src="https://d2xsxph8kpxj0f.cloudfront.net/310519663512579342/ahWG5azqh8H7YhFAqDURgu/bpc157-product-5mJurJVBjZ2ycKPDBiUZa8.webp"
                      alt="BPC-157 Peptide"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[oklch(0.14_0.025_250/60%)]" />
                  </div>
                </div>

                {/* Content */}
                <div className="md:w-3/5 p-6 lg:p-8 flex flex-col justify-between">
                  <div>
                    {/* Tags */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span
                        className="px-2 py-0.5 rounded text-xs bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)] border border-[oklch(0.72_0.20_178/20%)] purity-badge"
                      >
                        Pentadecapeptide
                      </span>
                      <span
                        className="px-2 py-0.5 rounded text-xs bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)] border border-[oklch(0.72_0.20_178/20%)] purity-badge"
                      >
                        ≥99% Purity
                      </span>
                    </div>

                    <h3
                      className="text-2xl lg:text-3xl font-bold text-white mb-2"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      BPC-157
                    </h3>
                    <p
                      className="text-xs text-[oklch(0.55_0.04_230)] mb-4 purity-badge"
                    >
                      Body Protection Compound · Pentadecapeptide · 1419 Da
                    </p>
                    <p className="text-sm text-[oklch(0.65_0.04_230)] leading-relaxed mb-6">
                      A 15-amino acid peptide derived from human gastric juice. Extensively studied for its regenerative properties in musculoskeletal tissue, gut health, and anti-inflammatory pathways.
                    </p>

                    {/* Key specs */}
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      {[
                        { label: "Molecular Weight", value: "1419 Da" },
                        { label: "Form", value: "Lyophilized" },
                        { label: "Storage", value: "-20°C" },
                        { label: "Sequence", value: "15 AA" },
                      ].map((spec) => (
                        <div key={spec.label} className="bg-[oklch(0.12_0.025_250)] rounded-lg p-2.5">
                          <div className="text-xs text-[oklch(0.50_0.03_230)] mb-0.5" style={{ fontFamily: "var(--font-mono)" }}>
                            {spec.label}
                          </div>
                          <div className="text-sm font-medium text-white" style={{ fontFamily: "var(--font-mono)" }}>
                            {spec.value}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-white" style={{ fontFamily: "var(--font-display)" }}>
                        From $49
                      </div>
                      <div className="text-xs text-[oklch(0.50_0.03_230)]">per vial</div>
                    </div>
                    <Link href="/products/bpc-157">
                      <Button
                        className="bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-bold"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        View Product
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── WHY APEX ─────────────────────────────────────────── */}
      <section className="py-24 bg-[oklch(0.10_0.025_250)]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Left: Image */}
            <div className="relative">
              <div className="rounded-2xl overflow-hidden teal-glow">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663512579342/ahWG5azqh8H7YhFAqDURgu/lab-science-QRTraHFnWDafaJLzFYHB4u.webp"
                  alt="Research Laboratory"
                  className="w-full h-[400px] object-cover"
                />
              </div>
              {/* Floating badge */}
              <div className="absolute -bottom-4 -right-4 bg-[oklch(0.14_0.025_250)] border border-[oklch(0.72_0.20_178/30%)] rounded-xl p-4 teal-glow">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[oklch(0.72_0.20_178/15%)] flex items-center justify-center">
                    <Award className="w-5 h-5 text-[oklch(0.72_0.20_178)]" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white" style={{ fontFamily: "var(--font-display)" }}>
                      ISO Certified
                    </div>
                    <div className="text-xs text-[oklch(0.55_0.04_230)]">Manufacturing</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Content */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="h-px w-[40px] bg-[oklch(0.72_0.20_178/40%)]" />
                <span
                  className="text-xs font-medium text-[oklch(0.72_0.20_178)] tracking-widest uppercase"
                  style={{ fontFamily: "var(--font-mono)" }}
                >
                  Why Choose Us
                </span>
              </div>
              <h2
                className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Precision You Can
                <br />
                <span className="teal-gradient-text">Trust</span>
              </h2>
              <p className="text-[oklch(0.65_0.04_230)] leading-relaxed mb-8">
                Every batch of Apex Peptides undergoes rigorous third-party testing via HPLC and mass spectrometry. We provide full Certificates of Analysis with every order.
              </p>

              <div className="space-y-4">
                {[
                  {
                    icon: <FlaskConical className="w-5 h-5" />,
                    title: "≥99% Purity Guaranteed",
                    desc: "Verified by independent HPLC and mass spectrometry analysis",
                  },
                  {
                    icon: <Shield className="w-5 h-5" />,
                    title: "Full COA with Every Order",
                    desc: "Batch-specific Certificate of Analysis available for download",
                  },
                  {
                    icon: <Microscope className="w-5 h-5" />,
                    title: "Research-Grade Synthesis",
                    desc: "Manufactured in ISO-certified facilities using solid-phase peptide synthesis",
                  },
                  {
                    icon: <Truck className="w-5 h-5" />,
                    title: "Discreet & Fast Shipping",
                    desc: "Dispatched within 48 hours in temperature-controlled packaging",
                  },
                ].map((item) => (
                  <div
                    key={item.title}
                    className="flex items-start gap-4 p-4 rounded-xl bg-[oklch(0.14_0.025_250)] border border-white/6 hover:border-[oklch(0.72_0.20_178/20%)] transition-colors"
                  >
                    <div className="w-9 h-9 rounded-lg bg-[oklch(0.72_0.20_178/15%)] flex items-center justify-center text-[oklch(0.72_0.20_178)] flex-shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <div
                        className="text-sm font-semibold text-white mb-0.5"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {item.title}
                      </div>
                      <div className="text-xs text-[oklch(0.55_0.04_230)] leading-relaxed">
                        {item.desc}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── RESEARCH HIGHLIGHTS ──────────────────────────────── */}
      <section className="py-24">
        <div className="container">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-[40px] bg-[oklch(0.72_0.20_178/40%)]" />
              <span
                className="text-xs font-medium text-[oklch(0.72_0.20_178)] tracking-widest uppercase"
                style={{ fontFamily: "var(--font-mono)" }}
              >
                Science
              </span>
              <div className="h-px w-[40px] bg-[oklch(0.72_0.20_178/40%)]" />
            </div>
            <h2
              className="text-4xl lg:text-5xl font-bold text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Research Highlights
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: <Zap className="w-6 h-6" />,
                title: "Triple Receptor Activation",
                product: "Retatrutide",
                desc: "Simultaneously activates GIP, GLP-1, and glucagon receptors — a mechanism unmatched by any other peptide in its class.",
                stat: "3×",
                statLabel: "Receptor Targets",
              },
              {
                icon: <Star className="w-6 h-6" />,
                title: "Significant Weight Reduction",
                product: "Retatrutide",
                desc: "Phase 2 trials demonstrated up to 24.2% mean body weight reduction at 48 weeks in the 12mg cohort.",
                stat: "24.2%",
                statLabel: "Weight Reduction",
              },
              {
                icon: <CheckCircle2 className="w-6 h-6" />,
                title: "Tissue Regeneration",
                product: "BPC-157",
                desc: "Promotes healing by boosting growth factors, reducing inflammation, and enhancing collagen synthesis in musculoskeletal tissue.",
                stat: "15 AA",
                statLabel: "Amino Acid Sequence",
              },
            ].map((card) => (
              <div
                key={card.title}
                className="relative rounded-2xl p-6 bg-[oklch(0.14_0.025_250)] border border-white/8 teal-glow-hover overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-[oklch(0.72_0.20_178/4%)] rounded-full -translate-y-1/2 translate-x-1/2" />

                <div className="w-11 h-11 rounded-xl bg-[oklch(0.72_0.20_178/15%)] flex items-center justify-center text-[oklch(0.72_0.20_178)] mb-4">
                  {card.icon}
                </div>

                <div
                  className="text-xs text-[oklch(0.72_0.20_178)] font-medium mb-2 purity-badge"
                >
                  {card.product}
                </div>

                <h3
                  className="text-lg font-bold text-white mb-3"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {card.title}
                </h3>
                <p className="text-sm text-[oklch(0.60_0.04_230)] leading-relaxed mb-6">
                  {card.desc}
                </p>

                <div className="border-t border-white/8 pt-4 flex items-end justify-between">
                  <div
                    className="text-3xl font-bold teal-gradient-text"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {card.stat}
                  </div>
                  <div className="text-xs text-[oklch(0.50_0.03_230)] text-right" style={{ fontFamily: "var(--font-mono)" }}>
                    {card.statLabel}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────────────── */}
      <section className="py-24 bg-[oklch(0.10_0.025_250)]">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="h-px w-[40px] bg-[oklch(0.72_0.20_178/40%)]" />
                <span
                  className="text-xs font-medium text-[oklch(0.72_0.20_178)] tracking-widest uppercase"
                  style={{ fontFamily: "var(--font-mono)" }}
                >
                  FAQ
                </span>
                <div className="h-px w-[40px] bg-[oklch(0.72_0.20_178/40%)]" />
              </div>
              <h2
                className="text-4xl font-bold text-white"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Common Questions
              </h2>
            </div>

            <div className="space-y-3">
              {[
                {
                  q: "Are these peptides for human use?",
                  a: "No. All products sold by Apex Peptides are strictly for research and laboratory purposes only. They are not intended for human consumption, medical treatment, or veterinary use. By purchasing, you confirm you are a qualified researcher.",
                },
                {
                  q: "What purity standards do you maintain?",
                  a: "All our peptides are synthesized to ≥99% purity, verified by HPLC (High-Performance Liquid Chromatography) and mass spectrometry. A batch-specific Certificate of Analysis (COA) is available for every product.",
                },
                {
                  q: "How should peptides be stored?",
                  a: "Lyophilized peptides should be stored at -20°C in a dry environment. Once reconstituted, store at 4°C and use within 30 days. Avoid repeated freeze-thaw cycles to maintain stability.",
                },
                {
                  q: "What is your shipping policy?",
                  a: "We dispatch all orders within 48 hours of payment confirmation. Products are shipped in temperature-controlled, discreet packaging. Domestic orders typically arrive within 3–5 business days.",
                },
                {
                  q: "Do you provide Certificates of Analysis?",
                  a: "Yes. Every batch comes with a full Certificate of Analysis from an independent third-party laboratory, confirming purity, identity, and absence of contaminants.",
                },
                {
                  q: "What is the difference between Retatrutide and BPC-157?",
                  a: "Retatrutide (LY3437943) is a triple-receptor agonist targeting GIP, GLP-1, and glucagon receptors, primarily studied for metabolic research. BPC-157 is a pentadecapeptide derived from human gastric juice, extensively studied for its regenerative and anti-inflammatory properties in musculoskeletal and gastrointestinal research.",
                },
              ].map((item) => (
                <FAQItem key={item.q} q={item.q} a={item.a} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ───────────────────────────────────────── */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 molecular-bg opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.72_0.20_178/8%)] to-transparent" />
        <div className="container relative z-10">
          <div className="max-w-2xl">
            <h2
              className="text-4xl lg:text-5xl font-bold text-white mb-4"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Ready to Start Your
              <br />
              <span className="teal-gradient-text">Research?</span>
            </h2>
            <p className="text-[oklch(0.65_0.04_230)] mb-8 leading-relaxed">
              Browse our catalog of premium research peptides. All orders include a Certificate of Analysis and are dispatched within 48 hours.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/products/retatrutide">
                <Button
                  size="lg"
                  className="bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-bold px-8 h-12"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Shop Retatrutide
                </Button>
              </Link>
              <Link href="/products/bpc-157">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/8 font-semibold px-8 h-12"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Shop BPC-157
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
