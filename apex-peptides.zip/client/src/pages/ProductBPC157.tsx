/* =============================================================
   PRODUCT PAGE — BPC-157
   Dark Scientific Precision Theme: Biotech Noir
   ============================================================= */

import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  ChevronRight,
  ShoppingCart,
  Shield,
  Truck,
  FileText,
  CheckCircle2,
  ChevronDown,
  ArrowLeft,
  Beaker,
  Heart,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

// ── Quantity Selector ───────────────────────────────────────────
function QuantitySelector({ qty, setQty }: { qty: number; setQty: (n: number) => void }) {
  return (
    <div className="flex items-center gap-0 border border-white/15 rounded-lg overflow-hidden">
      <button
        className="w-10 h-10 flex items-center justify-center text-[oklch(0.72_0.20_178)] hover:bg-white/5 transition-colors text-lg font-bold"
        onClick={() => setQty(Math.max(1, qty - 1))}
      >
        −
      </button>
      <div
        className="w-12 h-10 flex items-center justify-center text-white font-semibold text-sm border-x border-white/15"
        style={{ fontFamily: "var(--font-mono)" }}
      >
        {qty}
      </div>
      <button
        className="w-10 h-10 flex items-center justify-center text-[oklch(0.72_0.20_178)] hover:bg-white/5 transition-colors text-lg font-bold"
        onClick={() => setQty(qty + 1)}
      >
        +
      </button>
    </div>
  );
}

// ── Accordion ──────────────────────────────────────────────────
function Accordion({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-white/8">
      <button
        className="w-full flex items-center justify-between py-4 text-left"
        onClick={() => setOpen(!open)}
      >
        <span className="text-sm font-semibold text-white" style={{ fontFamily: "var(--font-display)" }}>
          {title}
        </span>
        <ChevronDown className={`w-4 h-4 text-[oklch(0.72_0.20_178)] transition-transform duration-300 ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="pb-4 text-sm text-[oklch(0.65_0.04_230)] leading-relaxed">
          {children}
        </div>
      )}
    </div>
  );
}

// ── Main Component ──────────────────────────────────────────────
export default function ProductBPC157() {
  const [qty, setQty] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState(0);

  const variants = [
    { label: "5mg", price: 49 },
    { label: "10mg", price: 89 },
    { label: "20mg", price: 159 },
  ];

  const totalPrice = variants[selectedVariant].price * qty;

  return (
    <div className="min-h-screen bg-[oklch(0.12_0.025_250)]">
      <Navbar />

      <main className="pt-24 pb-16">
        {/* Breadcrumb */}
        <div className="container mb-8">
          <div className="flex items-center gap-2 text-xs text-[oklch(0.50_0.03_230)]" style={{ fontFamily: "var(--font-mono)" }}>
            <Link href="/">
              <span className="hover:text-[oklch(0.72_0.20_178)] transition-colors cursor-pointer">Home</span>
            </Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-[oklch(0.72_0.20_178)]">BPC-157</span>
          </div>
        </div>

        {/* Back Button */}
        <div className="container mb-6">
          <Link href="/">
            <button className="flex items-center gap-1.5 text-sm text-[oklch(0.60_0.04_230)] hover:text-white transition-colors">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </button>
          </Link>
        </div>

        {/* Product Layout */}
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            {/* Left: Image */}
            <div className="sticky top-24">
              <div className="relative rounded-2xl overflow-hidden teal-glow bg-[oklch(0.14_0.025_250)]">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663512579342/ahWG5azqh8H7YhFAqDURgu/bpc157-product-5mJurJVBjZ2ycKPDBiUZa8.webp"
                  alt="BPC-157 Peptide Vial"
                  className="w-full aspect-square object-cover"
                />
                {/* Purity badge overlay */}
                <div className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-[oklch(0.12_0.025_250/80%)] backdrop-blur-sm border border-[oklch(0.72_0.20_178/30%)]">
                  <span className="text-xs font-medium text-[oklch(0.72_0.20_178)] purity-badge">
                    ≥99% PURITY
                  </span>
                </div>
              </div>

              {/* Trust badges */}
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[
                  { icon: <Shield className="w-4 h-4" />, label: "Secure Payment" },
                  { icon: <FileText className="w-4 h-4" />, label: "COA Included" },
                  { icon: <Truck className="w-4 h-4" />, label: "Fast Dispatch" },
                ].map((badge) => (
                  <div
                    key={badge.label}
                    className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-[oklch(0.14_0.025_250)] border border-white/8"
                  >
                    <div className="text-[oklch(0.72_0.20_178)]">{badge.icon}</div>
                    <span className="text-xs text-[oklch(0.55_0.04_230)] text-center" style={{ fontFamily: "var(--font-mono)" }}>
                      {badge.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Details */}
            <div>
              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                <span className="px-2.5 py-1 rounded-full text-xs bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)] border border-[oklch(0.72_0.20_178/20%)] purity-badge">
                  Pentadecapeptide
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)] border border-[oklch(0.72_0.20_178/20%)] purity-badge">
                  Gastric Origin
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)] border border-[oklch(0.72_0.20_178/20%)] purity-badge">
                  Research Grade
                </span>
              </div>

              <h1
                className="text-4xl lg:text-5xl font-bold text-white mb-2"
                style={{ fontFamily: "var(--font-display)" }}
              >
                BPC-157
              </h1>
              <p className="text-sm text-[oklch(0.55_0.04_230)] mb-2 purity-badge">
                Body Protection Compound · 15 Amino Acids · 1419 Da
              </p>
              <p className="text-xs text-[oklch(0.45_0.03_230)] mb-6 purity-badge break-all">
                Gly-Glu-Pro-Pro-Pro-Gly-Lys-Pro-Ala-Asp-Asp-Ala-Gly-Leu-Val
              </p>

              {/* Description */}
              <p className="text-[oklch(0.70_0.04_230)] leading-relaxed mb-8">
                BPC-157 (Body Protection Compound-157) is a synthetic pentadecapeptide consisting of 15 amino acids, originally isolated from human gastric juice. It has been extensively studied in preclinical models for its remarkable regenerative, anti-inflammatory, and cytoprotective properties across multiple tissue types.
              </p>

              {/* Specs Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
                {[
                  { label: "Sequence Length", value: "15 AA" },
                  { label: "Mol. Weight", value: "1419 Da" },
                  { label: "Purity", value: "≥99%" },
                  { label: "Form", value: "Lyophilized" },
                  { label: "Storage", value: "-20°C" },
                  { label: "Reconstitution", value: "Sterile Water" },
                  { label: "Stability", value: "24 Months" },
                  { label: "Origin", value: "Synthetic" },
                ].map((spec) => (
                  <div key={spec.label} className="bg-[oklch(0.14_0.025_250)] rounded-xl p-3 border border-white/6">
                    <div className="text-xs text-[oklch(0.45_0.03_230)] mb-1" style={{ fontFamily: "var(--font-mono)" }}>
                      {spec.label}
                    </div>
                    <div className="text-sm font-semibold text-white" style={{ fontFamily: "var(--font-mono)" }}>
                      {spec.value}
                    </div>
                  </div>
                ))}
              </div>

              {/* Variant Selector */}
              <div className="mb-6">
                <div className="text-sm font-semibold text-white mb-3" style={{ fontFamily: "var(--font-display)" }}>
                  Select Size
                </div>
                <div className="flex gap-3">
                  {variants.map((v, i) => (
                    <button
                      key={v.label}
                      onClick={() => setSelectedVariant(i)}
                      className={`flex-1 py-3 rounded-xl border text-sm font-semibold transition-all ${
                        selectedVariant === i
                          ? "border-[oklch(0.72_0.20_178)] bg-[oklch(0.72_0.20_178/15%)] text-[oklch(0.72_0.20_178)]"
                          : "border-white/15 text-[oklch(0.65_0.04_230)] hover:border-white/30"
                      }`}
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      {v.label}
                      <div className="text-xs font-normal mt-0.5 opacity-70">${v.price}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity + Price */}
              <div className="flex items-center gap-4 mb-6">
                <QuantitySelector qty={qty} setQty={setQty} />
                <div className="text-2xl font-bold text-white" style={{ fontFamily: "var(--font-display)" }}>
                  ${totalPrice}
                </div>
              </div>

              <Button
                size="lg"
                className="w-full bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-bold h-13 text-base mb-3"
                style={{ fontFamily: "var(--font-display)" }}
                onClick={() => toast.success(`Added ${qty}× BPC-157 ${variants[selectedVariant].label} to cart`)}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Add to Cart — ${totalPrice}
              </Button>

              <p className="text-xs text-center text-[oklch(0.45_0.03_230)] mb-8">
                For research purposes only. Not for human consumption.
              </p>

              {/* Accordions */}
              <div className="border-t border-white/8">
                <Accordion title="Research Applications">
                  <ul className="space-y-2">
                    {[
                      "Musculoskeletal tissue regeneration studies (tendons, ligaments, muscles)",
                      "Gastrointestinal healing and gut barrier integrity research",
                      "Anti-inflammatory pathway investigations",
                      "Angiogenesis and vascular repair models",
                      "Neuroprotection and neuromuscular healing studies",
                      "Bone healing and fracture repair research",
                    ].map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[oklch(0.72_0.20_178)] mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </Accordion>

                <Accordion title="Molecular Information">
                  <div className="space-y-3">
                    <div className="bg-[oklch(0.12_0.025_250)] rounded-lg p-4">
                      <div className="text-xs text-[oklch(0.50_0.03_230)] mb-2" style={{ fontFamily: "var(--font-mono)" }}>
                        CAS Number
                      </div>
                      <div className="text-sm text-[oklch(0.72_0.20_178)]" style={{ fontFamily: "var(--font-mono)" }}>
                        137525-51-0
                      </div>
                    </div>
                    <div className="bg-[oklch(0.12_0.025_250)] rounded-lg p-4">
                      <div className="text-xs text-[oklch(0.50_0.03_230)] mb-2" style={{ fontFamily: "var(--font-mono)" }}>
                        Full Amino Acid Sequence
                      </div>
                      <div className="text-xs text-[oklch(0.72_0.20_178)] break-all leading-relaxed" style={{ fontFamily: "var(--font-mono)" }}>
                        Gly-Glu-Pro-Pro-Pro-Gly-Lys-Pro-Ala-Asp-Asp-Ala-Gly-Leu-Val
                      </div>
                    </div>
                    <p>
                      BPC-157 exerts its regenerative effects through multiple interconnected pathways, including upregulation of growth factors (VEGF, EGF), modulation of the nitric oxide system, and interaction with the dopaminergic and serotonergic systems. Its stability in gastric juice makes it particularly suited for gastrointestinal research models.
                    </p>
                  </div>
                </Accordion>

                <Accordion title="Storage & Handling">
                  <ul className="space-y-2">
                    {[
                      "Store lyophilized peptide at -20°C, protected from light and moisture",
                      "Reconstitute with sterile bacteriostatic water or 0.9% saline",
                      "Once reconstituted, store at 4°C and use within 30 days",
                      "Avoid repeated freeze-thaw cycles to maintain peptide integrity",
                      "Handle in a sterile environment using aseptic technique",
                    ].map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[oklch(0.72_0.20_178)] mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </Accordion>

                <Accordion title="Shipping Information">
                  <p>
                    All orders are dispatched within 48 hours of payment confirmation. Products are shipped in insulated, temperature-controlled packaging. Domestic delivery typically takes 3–5 business days. International shipping is available to select research institutions. All packages are discreetly labeled.
                  </p>
                </Accordion>
              </div>
            </div>
          </div>
        </div>

        {/* Research Features */}
        <div className="container mt-20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: <Heart className="w-6 h-6" />,
                title: "Multi-Tissue Regeneration",
                desc: "Preclinical studies demonstrate accelerated healing in tendons, ligaments, muscles, bones, and gastrointestinal tissue through growth factor upregulation.",
              },
              {
                icon: <Zap className="w-6 h-6" />,
                title: "Anti-Inflammatory Pathways",
                desc: "BPC-157 modulates inflammatory cascades by interacting with the nitric oxide system and reducing pro-inflammatory cytokine expression.",
              },
              {
                icon: <Beaker className="w-6 h-6" />,
                title: "Gastric Stability",
                desc: "Unlike many peptides, BPC-157 demonstrates remarkable stability in gastric juice, making it uniquely suited for gastrointestinal research models.",
              },
            ].map((card) => (
              <div
                key={card.title}
                className="p-6 rounded-2xl bg-[oklch(0.14_0.025_250)] border border-white/8 teal-glow-hover"
              >
                <div className="w-11 h-11 rounded-xl bg-[oklch(0.72_0.20_178/15%)] flex items-center justify-center text-[oklch(0.72_0.20_178)] mb-4">
                  {card.icon}
                </div>
                <h3 className="text-base font-bold text-white mb-2" style={{ fontFamily: "var(--font-display)" }}>
                  {card.title}
                </h3>
                <p className="text-sm text-[oklch(0.60_0.04_230)] leading-relaxed">{card.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Also check out */}
        <div className="container mt-16">
          <div className="rounded-2xl p-8 bg-[oklch(0.14_0.025_250)] border border-white/8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <div className="text-xs text-[oklch(0.72_0.20_178)] mb-2 purity-badge">Also Available</div>
                <h3 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "var(--font-display)" }}>
                  Retatrutide
                </h3>
                <p className="text-sm text-[oklch(0.60_0.04_230)] max-w-md">
                  The next-generation triple receptor agonist for metabolic research. Demonstrated 24.2% weight reduction in Phase 2 trials.
                </p>
              </div>
              <Link href="/products/retatrutide">
                <Button
                  className="bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-bold whitespace-nowrap"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  View Retatrutide
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="container mt-8">
          <div className="rounded-xl p-5 bg-[oklch(0.75_0.16_75/8%)] border border-[oklch(0.75_0.16_75/20%)]">
            <p className="text-xs text-[oklch(0.70_0.10_75)] leading-relaxed" style={{ fontFamily: "var(--font-mono)" }}>
              ⚠ RESEARCH USE ONLY — BPC-157 is sold exclusively for in vitro research and laboratory use. It is not approved by the FDA or any other regulatory authority for human use. This product is not a drug, food, or cosmetic and should not be misbranded, misused, or mislabeled as such. Researchers must be qualified professionals and comply with all applicable laws and regulations.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
