/* =============================================================
   FOOTER — Apex Peptides
   Dark Scientific Precision Theme
   ============================================================= */

import { Link } from "wouter";
import { FlaskConical, Mail, Shield, FileText } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[oklch(0.10_0.025_250)] border-t border-white/8">
      {/* Disclaimer Banner */}
      <div className="bg-[oklch(0.75_0.16_75/10%)] border-b border-[oklch(0.75_0.16_75/20%)]">
        <div className="container py-3">
          <p
            className="text-xs text-[oklch(0.75_0.16_75)] text-center leading-relaxed"
            style={{ fontFamily: "var(--font-mono)" }}
          >
            ⚠ FOR RESEARCH PURPOSES ONLY — Not for human consumption. Not FDA approved. Must be 18+ to purchase.
          </p>
        </div>
      </div>

      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="md:col-span-2">
            <Link href="/">
              <div className="flex items-center gap-2.5 mb-4">
                <div className="w-8 h-8 rounded-lg bg-[oklch(0.72_0.20_178/15%)] border border-[oklch(0.72_0.20_178/40%)] flex items-center justify-center">
                  <FlaskConical className="w-4 h-4 text-[oklch(0.72_0.20_178)]" />
                </div>
                <div>
                  <span
                    className="text-lg font-bold tracking-tight text-white"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    APEX
                  </span>
                  <span
                    className="text-lg font-light tracking-widest text-[oklch(0.72_0.20_178)] ml-1"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    PEPTIDES
                  </span>
                </div>
              </div>
            </Link>
            <p className="text-sm text-[oklch(0.60_0.04_230)] leading-relaxed max-w-sm mb-6">
              Premium research-grade peptides manufactured to the highest standards of purity and quality. Trusted by researchers worldwide.
            </p>
            <div className="flex items-center gap-2 text-sm text-[oklch(0.60_0.04_230)]">
              <Mail className="w-4 h-4 text-[oklch(0.72_0.20_178)]" />
              <span>research@apexpeptides.com</span>
            </div>
          </div>

          {/* Products Column */}
          <div>
            <h4
              className="text-sm font-semibold text-white mb-4 tracking-wider uppercase"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Products
            </h4>
            <ul className="space-y-2.5">
              {[
                { href: "/products/retatrutide", label: "Retatrutide" },
                { href: "/products/bpc-157", label: "BPC-157" },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href}>
                    <span className="text-sm text-[oklch(0.60_0.04_230)] hover:text-[oklch(0.72_0.20_178)] transition-colors teal-underline">
                      {item.label}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Column */}
          <div>
            <h4
              className="text-sm font-semibold text-white mb-4 tracking-wider uppercase"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Legal
            </h4>
            <ul className="space-y-2.5">
              {[
                { label: "Terms of Service" },
                { label: "Privacy Policy" },
                { label: "Shipping Policy" },
                { label: "Research Disclaimer" },
              ].map((item) => (
                <li key={item.label}>
                  <span className="text-sm text-[oklch(0.60_0.04_230)] hover:text-[oklch(0.72_0.20_178)] transition-colors cursor-pointer teal-underline">
                    {item.label}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-white/8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[oklch(0.45_0.03_230)]">
            © {new Date().getFullYear()} Apex Peptides. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-xs text-[oklch(0.45_0.03_230)]">
              <Shield className="w-3.5 h-3.5 text-[oklch(0.72_0.20_178/60%)]" />
              <span>Secure Checkout</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[oklch(0.45_0.03_230)]">
              <FileText className="w-3.5 h-3.5 text-[oklch(0.72_0.20_178/60%)]" />
              <span>COA Available</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
