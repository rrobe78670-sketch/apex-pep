/* =============================================================
   NAVBAR — Apex Peptides
   Dark Scientific Precision Theme
   Sticky transparent-to-solid nav with teal accent
   ============================================================= */

import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, FlaskConical, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/products/retatrutide", label: "Retatrutide" },
    { href: "/products/bpc-157", label: "BPC-157" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[oklch(0.12_0.025_250/0.95)] backdrop-blur-md border-b border-white/8"
          : "bg-transparent"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-lg bg-[oklch(0.72_0.20_178/15%)] border border-[oklch(0.72_0.20_178/40%)] flex items-center justify-center group-hover:bg-[oklch(0.72_0.20_178/25%)] transition-colors">
                <FlaskConical className="w-4 h-4 text-[oklch(0.72_0.20_178)]" />
              </div>
              <div>
                <span
                  className="text-lg font-bold tracking-tight text-white"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  APEX
                </span>
                <span
                  className="text-lg font-light tracking-widest text-[oklch(0.72_0.20_178)] ml-1"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  PEPTIDES
                </span>
              </div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`text-sm font-medium transition-colors teal-underline ${
                    location === link.href
                      ? "text-[oklch(0.72_0.20_178)]"
                      : "text-[oklch(0.75_0.04_230)] hover:text-white"
                  }`}
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => toast.info("Cart feature coming soon")}
              className="w-9 h-9 rounded-lg border border-white/10 flex items-center justify-center text-[oklch(0.75_0.04_230)] hover:text-[oklch(0.72_0.20_178)] hover:border-[oklch(0.72_0.20_178/40%)] transition-all"
            >
              <ShoppingCart className="w-4 h-4" />
            </button>
            <Button
              onClick={() => toast.info("Account feature coming soon")}
              size="sm"
              className="bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-semibold px-4"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Order Now
            </Button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden w-9 h-9 flex items-center justify-center text-[oklch(0.75_0.04_230)] hover:text-white"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-[oklch(0.14_0.025_250/0.98)] backdrop-blur-md border-b border-white/8">
          <div className="container py-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`block text-sm font-medium py-2 transition-colors ${
                    location === link.href
                      ? "text-[oklch(0.72_0.20_178)]"
                      : "text-[oklch(0.75_0.04_230)]"
                  }`}
                  style={{ fontFamily: "var(--font-display)" }}
                  onClick={() => setMobileOpen(false)}
                >
                  {link.label}
                </span>
              </Link>
            ))}
            <Button
              onClick={() => { toast.info("Order feature coming soon"); setMobileOpen(false); }}
              size="sm"
              className="bg-[oklch(0.72_0.20_178)] text-[oklch(0.10_0.02_250)] hover:bg-[oklch(0.78_0.18_180)] font-semibold w-full"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Order Now
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
